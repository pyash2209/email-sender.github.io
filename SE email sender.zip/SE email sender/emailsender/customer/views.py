from django.shortcuts import render,redirect
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages

def email(request):
    return render(request,'customer/email.html')

def email_info(request):
   myto = request.POST['to']
   mysub = request.POST['subject']
   mymess = request.POST['message']

 

   send_mail (mysub,mymess,settings.EMAIL_HOST_USER,[myto],fail_silently= False)
   messages.success(request, 'your mail is sent successfully!!!')
   return redirect('/customer/email/')